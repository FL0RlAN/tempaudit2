# -*- coding: utf-8 -*-


class Taskscheduler(object):
    def __init__(self):
        self.name = None
        self.full_path = None
        self.paths = []
        self.userid = None
        self.groupid = None
        self.runlevel = None

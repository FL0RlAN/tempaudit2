# -*- coding: utf-8 -*-


class Software(object):
    """
    Manage one software
    """
    def __init__(self):
        self.name = None
        self.version = None
        self.key = None
